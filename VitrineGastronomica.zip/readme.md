#Some setup information :).

##JSF setup

If you are in ServletContainer, like Tomcat or Jetty, alter your pom.xml in order to change the scope of **jsf-api** from
**provided** to **compile**.
  	
##JAVA EE JPA setup

You need to change your **persistence.xml** file and put your login, password and url information about the database.
  	

